#if UNITY_EDITOR
using UnityEditor;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
#if UNITY_2021_2_OR_NEWER
    using UnityEditor.Toolbars;
    using UnityEngine;
    using UnityEngine.UIElements;

    /// <summary>SceneView 상단 툴바의 전역 잠금 토글 버튼.</summary>
    [EditorToolbarElement("SceneView/UMX Global Lock")]
    public class UMXGlobalLockToolbarButton : EditorToolbarToggle
    {
        public UMXGlobalLockToolbarButton()
        {
            this.tooltip = "Lock / Unlock all UModelerX objects";
            // UModelerX 자체 아이콘 사용. on=Lock(닫힌 자물쇠), off=Unlock(열린 자물쇠).
            this.onIcon = Resources.Load<Texture2D>("Tripolygon/UModelerX/Editor/Views/Inspector/SourceMeshItemView/Lock");
            this.offIcon = Resources.Load<Texture2D>("Tripolygon/UModelerX/Editor/Views/Inspector/SourceMeshItemView/Unlock");

            this.SetValueWithoutNotify(UMXLockState.IsGlobalLocked);
            this.RegisterValueChangedCallback(evt => UMXLockState.SetGlobalLocked(evt.newValue));

            // 다른 진입점(메뉴 등)으로 상태가 바뀌면 버튼도 동기화.
            UMXLockState.LockChanged += SyncFromState;
            this.RegisterCallback<DetachFromPanelEvent>(_ => UMXLockState.LockChanged -= SyncFromState);
        }

        private void SyncFromState()
        {
            this.SetValueWithoutNotify(UMXLockState.IsGlobalLocked);
        }
    }
#endif
}
#endif
